package theconstrictorpackagemod.util;

public class KeywordInfo {
    public String ID = "";
    public String PROPER_NAME;
    public String DESCRIPTION;
    public String[] NAMES;
    public String[] EXTRA = new String[] {};

    public KeywordInfo() {
    }
}